<!DOCTYPE html>
<html>
<head>
<title>Tambah Data Matakuliah</title>
</head>
<body>
<h2>Tambah Data Matakuliah</h2>
<br/>
<a href="index.php">KEMBALI</a>
<br/>
<form method="post" action="tambah_aksi.php">
<table>
<tr>
<td>Kode</td>
<td><input type="number" name="kode_matakuliah"></td>
</tr>
<tr>
<td>Nama matakulian</td>
<td><input type="text" name="nama_matakuliah"></td>
</tr>
<tr>
<td>sks</td>
<td><input type="text" name="sks"></td>
</tr>
<tr>
<td></td>
<td><input type="submit" value="SIMPAN"></td>
</tr>
</table>
</form>
</body>
</html>