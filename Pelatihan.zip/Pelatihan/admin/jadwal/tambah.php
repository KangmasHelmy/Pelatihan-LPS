<!DOCTYPE html>
<html>
<head>
<title>Tambah Data Jadwal</title>
</head>
<body>
<h2>Tambah Data Jadwal</h2>
<br/>
<a href="index.php">KEMBALI</a>
<br/>
<form method="post" action="tambah_aksi.php">
<table>
<tr>
    <td>Matkul</td>
    <td>
        <select name="matakuliah">
            <?php
            include '../../koneksi.php';
            $data = mysqli_query($koneksi,"select * from tbl_matkul"); 
            while($d = mysqli_fetch_array($data)){
            ?>
            <option value="<?php echo $d['nama_matkul']; ?>"><?php echo $d['nama_matkul']; ?></option>
            <?php
            }
            ?>
            
        </select>
    </td>
</tr>
<tr>
    <td>Dosen</td>
    <td><input type="text" name="nama_dosen"></td>
</tr>
<tr>
    <td>Ruang</td>
    <td><input type="text" name="alamat"></td>
</tr>
<tr>
    <td>Waktu</td>
    <td><input type="text" name="alamat"></td>
</tr>
<tr>
<td></td>
    <td><input type="submit" value="SIMPAN"></td>
</tr>
</table>
</form>
</body>
</html>